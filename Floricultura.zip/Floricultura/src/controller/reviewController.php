<?php
namespace Controller;

use Model\ReviewsModel;

session_start(); // Inicia a sessão para acessar os dados do usuário

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['user_id'])) {
        if (isset($_POST['nota'], $_POST['comentario'], $_POST['produto_id'])) {
            $nota = $_POST['nota'];
            $comentario = $_POST['comentario'];
            $produto_id = $_POST['produto_id'];

            $review = new ReviewsModel();
            $review->setNota($nota);
            $review->setComentario($comentario);
            $review->setProdutosId($produto_id);
            $review->setUsuariosId($_SESSION['user_id']); // Pega o ID do usuário da sessão
            $review->saveReview();
            setcookie('review_success', 'Comentário salvo com sucesso!', time() + 5, '/'); 
            header('Location: ../exibirProduto.php?id=' . $produto_id);
            exit;
        } else {
            echo "Erro ao enviar comentário! Por favor, preencha todos os campos.";
        }
    } else {
        echo "Você precisa estar logado para deixar uma avaliação.";
    }
}
?>
