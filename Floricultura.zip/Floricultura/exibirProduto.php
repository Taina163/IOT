<?php
require_once './shared/header.php';
use Model\produtosModel;
use Model\ReviewsModel;

if ($_REQUEST['id']) {
    require_once 'src/model/produtosModel.php';
    $produto = new produtosModel();
    $result = $produto->loadById($_REQUEST['id']); // chama o id do produto

    echo('<div class="container">');
    echo ('<div class="row">');
    foreach ($result as $produtos) {
        echo('<div class="col-md-6">');
        echo('<h2>' . $produtos['nome'] . '</h2>');
        echo('<p>' . $produtos['descricao'] . '</p>');
        echo('<img src="' . $produtos['imagem'] . '" style="height: 200px;width:300px">');
        echo('<h4>Valor: R$' . $produtos['preco_base'] . '</h4>');
        echo('<a class="d-grid btn btn-info" href="src/controller/carrinhoController.php?id=' . $produtos['id'] . '">Adicionar ao carrinho</a>');
        echo('</div>');
    }
    echo ('</div>');

    // Exibe mensagem de sucesso
    if (isset($_COOKIE['review_success'])) {
        echo('<div class="alert alert-success mt-4" role="alert">' . $_COOKIE['review_success'] . '</div>');
        setcookie('review_success', '', time() - 3600, '/');
    }

    echo('<div class="col-md-12 mt-4">');
    echo('<h3>Deixe sua Avaliação</h3>');
    echo('<form action="src/controller/reviewController.php" method="post">');
    echo('<input type="hidden" name="produto_id" value="' . $produtos['id'] . '">');
    echo('<div class="form-group">');
    echo('<label for="nota">Nota (1 a 5):</label>');
    echo('<input type="number" id="nota" name="nota" class="form-control" min="1" max="5" required>');
    echo('</div>');
    echo('<div class="form-group mt-3">');
    echo('<label for="comentario">Comentário:</label>');
    echo('<textarea id="comentario" name="comentario" class="form-control" rows="4" required></textarea>');
    echo('</div>');
    echo('<button type="submit" class="btn btn-primary mt-3">Enviar Comentário</button>');
    echo('</form>');
    echo('</div>');
    echo('</div>');
    echo('</div>');
}
?>
</body>
</html>
